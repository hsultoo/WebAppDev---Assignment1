package com.example.emicalculator;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.emicalculator.databinding.FragmentFirstBinding;

import java.security.Principal;

public class FirstFragment extends Fragment {

    private FragmentFirstBinding binding;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState

    ) {

        binding = FragmentFirstBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        //refer to the button that will calculate the EMI and set an OnClickListener.
        view.findViewById(R.id.calculate).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //call the function that will perform the calculaion when the button is pressed
                calculateEMI(view);

            }
        });

    }

    //define methos that will perform the calculation when the button is pressed
    public void calculateEMI(View view){

        //access the user input for principal, convert to string and parse to double datatype for calculation
        TextView Principal = (TextView) getView().findViewById(R.id.principalNum);
        String principal = Principal.getText().toString();
        double P = Double.parseDouble(principal);

        //access the user input for the annual interest in %, convert to string and parse to double datatype for calculation
        TextView Interest = (TextView) getView().findViewById(R.id.interestNum);
        String interest = Interest.getText().toString();
        double I = Double.parseDouble(interest);

        //access the user input for the duration or term in years, convert to string and parse to double datatype for calculation
        TextView Tenure = (TextView) getView().findViewById(R.id.tenureNum);
        String tenure = Tenure.getText().toString();
        double T = Double.parseDouble(tenure);

        //number of months in a year
        int n = 12;

        //interest as a fraction
        double inter = I/100;

        //compute the complicated power calculation
        double powerCalc = Math.pow((1+(inter/n)), (n*T));

        //substitute the power calculation in the mortgage EMI equation (from https://www.thebalance.com/calculate-mortgage-315668)
        double emi = (P*(inter/n)*powerCalc) / (powerCalc-1);

        //access the view where the output will be displayed and use setText to allow display.
        TextView EMIval = (TextView) getView().findViewById(R.id.emiVal);
        EMIval.setText("$" + String.valueOf(emi));
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}